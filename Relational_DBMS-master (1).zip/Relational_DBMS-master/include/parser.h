#include "declaration.h"

extern void get_query();

extern void parse_create();
